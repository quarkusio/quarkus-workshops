package io.quarkus.workshop.superheroes.narration;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NarrationResourceIT extends NarrationResourceTest {
    // Execute the same tests but in packaged mode.
}
