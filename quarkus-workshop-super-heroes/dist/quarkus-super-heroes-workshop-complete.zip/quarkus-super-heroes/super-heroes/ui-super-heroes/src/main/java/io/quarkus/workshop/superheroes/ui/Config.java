package io.quarkus.workshop.superheroes.ui;

public record Config(String API_BASE_URL, boolean CALCULATE_API_BASE_URL) {
}
