import {Component} from '@angular/core';

@Component({
  selector: 'hero-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'Super Heroes Fight';
}
