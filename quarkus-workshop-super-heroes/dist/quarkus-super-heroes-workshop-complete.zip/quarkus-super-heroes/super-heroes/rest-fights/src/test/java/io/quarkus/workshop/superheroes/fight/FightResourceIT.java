package io.quarkus.workshop.superheroes.fight;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class FightResourceIT extends FightResourceTest {
    // Execute the same tests but in packaged mode.
}
